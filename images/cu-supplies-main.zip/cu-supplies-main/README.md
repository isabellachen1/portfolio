# CU Supplies
A website that allows Cornell students to sell school supplies to others.

Contributors: 
<br> Jacqueline Cai <br> Vivian Zhou <br> Isabella Chen <br> Selina Lin <br> Jenny Chen <br> Yuxuan Lin
